# @datafox/ui

**Datafox UI** 是一个面向可观测产品的开源 React 设计系统。它以 DRUIDS 的公开文档和运行时体验为参照，复刻高密度界面的视觉语言与交互契约；实现基于 Radix、Tailwind v4 和 CVA，并以 Apache-2.0 发布。

它不是中性的“万能组件库”，也不是 DRUIDS 的分支。Datafox UI 的价值在于让表格、筛选、状态、时间、数据度量和复杂导航拥有同一套可预测的产品语言，而不是提供任意换肤或无限扩展的组件集合。

> **当前状态：**源码版本为 `0.1.13`，公开包身份为 `@datafox/ui`。此仓库提供源码和可构建的打包产物，不表示该版本已发布到 npm。

## 一套系统，而不是一组零散组件

设计令牌是视觉唯一真相；组件负责可访问的交互；组合模式把它们带进真实的可观测工作流。画廊本身也使用这套公开组件构建，是组件 API 的真实使用场景，而非静态展示页。

```mermaid
flowchart LR
  F["Foundations<br/>颜色 · 间距 · 排版 · 阴影 · 圆角 · 数据可视化"]
  P["Primitives<br/>布局 · 表单 · 导航 · 浮层 · 数据展示"]
  M["Patterns<br/>筛选 · 状态反馈 · 高密度工作流"]
  O["Observable products<br/>Datafox 平台与产品集成"]

  F --> P --> M --> O
```

### 已有能力

| 领域                | 代表能力                                                                                                                                                               |
| ------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Foundations         | 语义色、明暗主题、8px 间距刻度、Basic / Editorial 排版、6 级 Elevation、圆角与 dataviz 色板                                                                            |
| Layout & navigation | Flex、Grid、Spacing、Stack、Panel、Header、SidebarLayout、DraggablePane、ProductHeader、TabList                                                                        |
| Form & feedback     | Button、Group、Label、TextField、InputSearch、Select / MultiSelect、Checkbox、Radio、Switch、Dialog、Tooltip、Popover、DropdownMenu、Toast                             |
| Dense data UI       | Table、ActionTray、Code、CopyButton、Calendar、DateRangePicker、FormattedNumber、FormattedTime、FormattedElapsedTime、PercentBar、PercentDonut、ScoreBar、CalloutValue |
| Labels & icons      | 12 个 pills 组件（Tag、Badge、StatusPill 等）和 441 个按需导出的内联 SVG 图标                                                                                          |

完整的组件状态、对齐证据和后续工作见 [组件复刻矩阵](./docs/parity/component-matrix.md)。没有对应 DRUIDS 能力的扩展，默认不进入范围。

## 本地运行与接入

### 运行 Playground

```bash
git clone https://github.com/XiaoWeiKIN/datafox-ui.git
cd datafox-ui
pnpm install
pnpm dev
```

Playground 默认运行在 [http://localhost:5174](http://localhost:5174)。它对齐 DRUIDS 文档站，包含 foundations、设计原则、模式说明、组件文档与可交互示例，也是组件实验和验收入口。

运行 `pnpm build:playground` 构建静态画廊，产物位于 `playground/dist`。组件库仍由 `pnpm build` 输出到 `dist`，两种产物分别存放。

### 在本地构建后消费

先构建库，再通过工作区、`pnpm link` 或打包产物接入你的 React 项目：

```bash
pnpm build
pnpm pack
```

构建产物提供 ESM、类型声明和 `styles.css`。将生成的 tarball 安装到下游项目：

```bash
pnpm add /path/to/datafox-ui-0.1.13.tgz
```

运行要求：Node.js 18+；React 与 React DOM `^18.3.1 || ^19.0.0`。

## 最小使用示例

样式需要显式引入。`ThemeProvider` 只负责在 `<html>` 上切换 `.dark`，因此 Portal 渲染的 Dialog、Popover、Tooltip、Select 等浮层也能继承正确主题。

```tsx
import '@datafox/ui/styles.css';
import { Button, ThemeProvider } from '@datafox/ui';

export function App() {
  return (
    <ThemeProvider scheme="dark">
      <Button variant="primary" level="success" size="md">
        Save view
      </Button>
    </ThemeProvider>
  );
}
```

设计令牌从独立子路径导入；它不依赖 React，适合图表、数据格式化或与其他渲染层共享配置。

```ts
import { dataviz, tokens } from '@datafox/ui/tokens';

const chartColor = dataviz.categorical[0];
const panelGap = tokens.space.md;
```

## 设计与实现原则

- **高保真优先于功能泛化。** 先验证 DRUIDS 是否具备该能力；有官方 shadcn 组件时保留其行为层，只校准 Datafox UI 的密度与令牌。
- **Foundations 是唯一视觉来源。** 组件和产品界面使用语义 CSS 变量、布局原语与设计令牌，不用散落的 hex、任意间距或自定义阴影拼出相似效果。
- **交互必须完整。** 每个交互组件都要考虑 loading、empty、error、disabled、键盘与 a11y，而不是只完成默认态。
- **主题不是可配置产品能力。** 支持亮/暗模式以保持参照系统的真实体验；不提供皮肤、品牌换色或任意主题定制。

让 AI Agent 使用 Datafox UI 开发产品时，从 [Agent Contract](./docs/agents/README.md) 开始；其中 [Principles](./docs/agents/principles.md) 约束内容与交互，[Foundations](./docs/agents/foundations.md) 约束所有视觉取值，并按需进入 [排版](./docs/agents/typography.md) 与 [间距布局](./docs/agents/spacing-layout.md) 专项手册。
完整的规范、对齐台账与研究记录从 [文档中心](./docs/README.md) 进入。

## 架构

| 层                     | 职责                                                        |
| ---------------------- | ----------------------------------------------------------- |
| `src/styles/theme.css` | 运行时主题与公开 CSS 变量契约                               |
| `src/tokens`           | 可导入的纯数据令牌                                          |
| `src/components/ui`    | 以 shadcn / Radix 为行为基础、经密度校准的组件              |
| `src/primitives`       | shadcn 没有对应物时的自研原语与复合组件                     |
| `src/icons`            | 可 tree-shake 的内联 SVG 图标导出；画廊注册表不进入根入口   |
| `playground`           | 对齐 DRUIDS 文档站的本地 Playground；也是组件实验与验收入口 |

公开入口为 `@datafox/ui`、`@datafox/ui/tokens`、`@datafox/ui/theme` 与 `@datafox/ui/styles.css`。CSS 变量名属于公开契约，重命名视为 breaking change。

## 开发与质量检查

```bash
pnpm dev          # Playground → http://localhost:5174
pnpm build        # ESM、.d.ts 与 dist/styles.css
pnpm typecheck
pnpm test
pnpm lint
pnpm format:check
```

提交组件变更时，请同步更新相邻测试与 [`docs/parity/`](./docs/parity/README.md) 中对应的台账。涉及真实交互状态时，还应在画廊中手动检查 hover、focus、键盘操作和明暗主题。

## 独立性声明

Datafox UI 是独立的 inspired-by 实现，与 Datadog 无隶属关系，也未获其背书。DRUIDS 仅作为公开设计参照；项目名称、包名与发布物均使用 Datafox UI，避免被误认为官方产品或其衍生分支。

## License

[Apache-2.0](./LICENSE)
